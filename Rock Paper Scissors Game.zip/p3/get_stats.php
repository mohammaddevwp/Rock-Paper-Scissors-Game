<?php
require_once 'db.php';

header('Content-Type: application/json');

try {
    $stats = [
        'total' => 0,
        'wins' => 0,
        'losses' => 0,
        'draws' => 0
    ];
    
    // Get total games
    $stmt = $pdo->query("SELECT COUNT(*) FROM game_rounds");
    $stats['total'] = $stmt->fetchColumn();
    
    // Get wins
    $stmt = $pdo->query("SELECT COUNT(*) FROM game_rounds WHERE result = 'win'");
    $stats['wins'] = $stmt->fetchColumn();
    
    // Get losses
    $stmt = $pdo->query("SELECT COUNT(*) FROM game_rounds WHERE result = 'lose'");
    $stats['losses'] = $stmt->fetchColumn();
    
    // Get draws
    $stmt = $pdo->query("SELECT COUNT(*) FROM game_rounds WHERE result = 'draw'");
    $stats['draws'] = $stmt->fetchColumn();
    
    echo json_encode($stats);
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
}
?>
