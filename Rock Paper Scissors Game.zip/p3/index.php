<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rock Paper Scissors Game</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css">
</head>
<body class="bg-light" id="main-body">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <h1 class="text-center mb-0">Rock Paper Scissors Game</h1>
                            <button id="theme-toggle" class="btn btn-outline-secondary ms-2" title="تغییر تم">
                                <i class="bi bi-moon-stars-fill" id="theme-icon"></i>
                            </button>
                        </div>
                        
                        <div class="mb-4">
                            <label for="rounds" class="form-label">Number of Rounds:</label>
                            <select class="form-select" id="rounds">
                                <option value="3">3 Rounds</option>
                                <option value="5">5 Rounds</option>
                                <option value="7">7 Rounds</option>
                            </select>
                        </div>

                        <div class="d-flex justify-content-center gap-3 mb-4">
                            <button class="btn btn-lg btn-outline-primary choice-btn" data-choice="rock">
                                <i class="bi bi-circle-fill"></i> Rock
                            </button>
                            <button class="btn btn-lg btn-outline-primary choice-btn" data-choice="paper">
                                <i class="bi bi-file-earmark"></i> Paper
                            </button>
                            <button class="btn btn-lg btn-outline-primary choice-btn" data-choice="scissors">
                                <i class="bi bi-scissors"></i> Scissors
                            </button>
                        </div>

                        <div class="result-section mb-4">
                            <div class="alert alert-info">
                                <p id="user-choice">You chose: -</p>
                                <p id="computer-choice">Computer chose: -</p>
                                <p id="round-result">Result: -</p>
                                <p id="round-counter">Round: 0/0</p>
                            </div>
                        </div>

                        <div class="stats-panel">
                            <h3 class="mb-3">Statistics</h3>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="card bg-primary text-white">
                                        <div class="card-body text-center">
                                            <h5>Total Games</h5>
                                            <h3 id="total-games">0</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="card bg-success text-white">
                                        <div class="card-body text-center">
                                            <h5>Wins</h5>
                                            <h3 id="wins">0</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="card bg-danger text-white">
                                        <div class="card-body text-center">
                                            <h5>Losses</h5>
                                            <h3 id="losses">0</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="card bg-warning text-white">
                                        <div class="card-body text-center">
                                            <h5>Draws</h5>
                                            <h3 id="draws">0</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="final-summary" class="alert alert-secondary text-center mt-4 d-none"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="game.js"></script>
</body>
</html>
