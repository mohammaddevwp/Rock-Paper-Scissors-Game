CREATE DATABASE IF NOT EXISTS rps_game;
USE rps_game;

CREATE TABLE IF NOT EXISTS game_rounds (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_choice VARCHAR(10) NOT NULL,
    computer_choice VARCHAR(10) NOT NULL,
    result VARCHAR(10) NOT NULL,
    created_at DATETIME NOT NULL
);
