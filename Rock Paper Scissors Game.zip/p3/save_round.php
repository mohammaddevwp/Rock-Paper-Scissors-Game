<?php
require_once 'db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userChoice = $_POST['userChoice'] ?? '';
    $computerChoice = $_POST['computerChoice'] ?? '';
    $result = $_POST['result'] ?? '';
    
    if ($userChoice && $computerChoice && $result) {
        try {
            $stmt = $pdo->prepare("INSERT INTO game_rounds (user_choice, computer_choice, result, created_at) VALUES (?, ?, ?, NOW())");
            $stmt->execute([$userChoice, $computerChoice, $result]);
            
            echo json_encode(['success' => true]);
        } catch(PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
        }
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'Missing required parameters']);
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
}
?>
