document.addEventListener('DOMContentLoaded', function() {
    let currentRound = 0;
    let totalRounds = 3;
    let gameActive = false;
    let winCount = 0, loseCount = 0, drawCount = 0;

    const roundsSelect = document.getElementById('rounds');
    const choiceButtons = document.querySelectorAll('.choice-btn');
    const userChoiceDisplay = document.getElementById('user-choice');
    const computerChoiceDisplay = document.getElementById('computer-choice');
    const roundResultDisplay = document.getElementById('round-result');
    const roundCounterDisplay = document.getElementById('round-counter');
    const resultSection = document.querySelector('.result-section');
    const themeToggle = document.getElementById('theme-toggle');
    const themeIcon = document.getElementById('theme-icon');
    const mainBody = document.getElementById('main-body');
    const finalSummary = document.getElementById('final-summary');

    // تم ذخیره شده را بارگذاری کن
    if (localStorage.getItem('theme') === 'dark') {
        setDarkMode(true);
    }

    themeToggle.addEventListener('click', function() {
        const isDark = mainBody.classList.toggle('dark-mode');
        setDarkMode(isDark);
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
    });

    function setDarkMode(isDark) {
        if (isDark) {
            mainBody.classList.add('dark-mode');
            themeIcon.classList.remove('bi-moon-stars-fill');
            themeIcon.classList.add('bi-brightness-high-fill');
        } else {
            mainBody.classList.remove('dark-mode');
            themeIcon.classList.remove('bi-brightness-high-fill');
            themeIcon.classList.add('bi-moon-stars-fill');
        }
    }

    // افکت موجی روی دکمه‌ها
    choiceButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            // Ripple
            const ripple = document.createElement('span');
            ripple.className = 'ripple';
            const rect = button.getBoundingClientRect();
            ripple.style.left = (e.clientX - rect.left) + 'px';
            ripple.style.top = (e.clientY - rect.top) + 'px';
            button.appendChild(ripple);
            setTimeout(() => ripple.remove(), 600);
        });
    });

    // Event Listeners
    roundsSelect.addEventListener('change', function() {
        totalRounds = parseInt(this.value);
        resetGame();
    });

    choiceButtons.forEach(button => {
        button.addEventListener('click', function() {
            if (!gameActive) {
                gameActive = true;
                currentRound = 0;
            }
            
            if (currentRound < totalRounds) {
                const userChoice = this.dataset.choice;
                this.classList.add('active');
                setTimeout(() => this.classList.remove('active'), 300);
                playRound(userChoice);
            }
        });
    });

    // Game Functions
    function playRound(userChoice) {
        const computerChoice = getComputerChoice();
        const result = determineWinner(userChoice, computerChoice);
        
        resultSection.classList.remove('win-animation', 'lose-animation', 'draw-animation');
        void resultSection.offsetWidth;
        resultSection.classList.add(`${result}-animation`);
        
        updateDisplay(userChoice, computerChoice, result);
        saveRound(userChoice, computerChoice, result);
        updateStats();
        
        if(result === 'win') winCount++;
        if(result === 'lose') loseCount++;
        if(result === 'draw') drawCount++;
        
        currentRound++;
        if (currentRound >= totalRounds) {
            setTimeout(() => {
                showGameOver();
                showFinalSummary();
                gameActive = false;
            }, 500);
        }
    }

    function getComputerChoice() {
        const choices = ['rock', 'paper', 'scissors'];
        return choices[Math.floor(Math.random() * 3)];
    }

    function determineWinner(userChoice, computerChoice) {
        if (userChoice === computerChoice) return 'draw';
        
        const winConditions = {
            rock: 'scissors',
            paper: 'rock',
            scissors: 'paper'
        };
        
        return winConditions[userChoice] === computerChoice ? 'win' : 'lose';
    }

    function updateDisplay(userChoice, computerChoice, result) {
        userChoiceDisplay.style.opacity = '0';
        setTimeout(() => {
            userChoiceDisplay.textContent = `You chose: ${userChoice}`;
            userChoiceDisplay.style.opacity = '1';
        }, 200);

        computerChoiceDisplay.style.opacity = '0';
        setTimeout(() => {
            computerChoiceDisplay.textContent = `Computer chose: ${computerChoice}`;
            computerChoiceDisplay.style.opacity = '1';
        }, 400);

        roundResultDisplay.style.opacity = '0';
        setTimeout(() => {
            roundResultDisplay.textContent = `Result: You ${result}`;
            roundResultDisplay.style.opacity = '1';
        }, 600);

        roundCounterDisplay.textContent = `Round: ${currentRound + 1}/${totalRounds}`;
    }

    function resetGame() {
        currentRound = 0;
        gameActive = false;
        userChoiceDisplay.textContent = 'You chose: -';
        computerChoiceDisplay.textContent = 'Computer chose: -';
        roundResultDisplay.textContent = 'Result: -';
        roundCounterDisplay.textContent = `Round: 0/${totalRounds}`;
        resultSection.classList.remove('win-animation', 'lose-animation', 'draw-animation');
        winCount = 0; loseCount = 0; drawCount = 0;
        finalSummary.classList.add('d-none');
        finalSummary.innerHTML = '';
    }

    function showGameOver() {
        const gameOverDiv = document.createElement('div');
        gameOverDiv.className = 'alert alert-success text-center game-over-alert';
        gameOverDiv.innerHTML = `
            <h3>Game Over!</h3>
            <p>Check the statistics panel for results.</p>
        `;
        resultSection.appendChild(gameOverDiv);
        
        setTimeout(() => {
            gameOverDiv.remove();
        }, 3000);
    }

    function showFinalSummary() {
        finalSummary.innerHTML = `
            <h4>خلاصه بازی</h4>
            <div>برد: <b>${winCount}</b> | باخت: <b>${loseCount}</b> | مساوی: <b>${drawCount}</b></div>
        `;
        finalSummary.classList.remove('d-none');
        finalSummary.classList.add('animate__animated', 'animate__fadeInDown');
        setTimeout(() => finalSummary.classList.remove('animate__animated', 'animate__fadeInDown'), 1200);
    }

    function saveRound(userChoice, computerChoice, result) {
        fetch('save_round.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `userChoice=${userChoice}&computerChoice=${computerChoice}&result=${result}`
        })
        .catch(error => console.error('Error saving round:', error));
    }

    function updateStats() {
        fetch('get_stats.php')
            .then(response => response.json())
            .then(data => {
                const stats = ['total-games', 'wins', 'losses', 'draws'];
                stats.forEach(stat => {
                    const element = document.getElementById(stat);
                    element.style.transform = 'scale(1.2)';
                    setTimeout(() => {
                        element.textContent = data[stat.replace('-games', '')];
                        element.style.transform = 'scale(1)';
                    }, 200);
                });
            })
            .catch(error => console.error('Error updating stats:', error));
    }

    // Initial stats load
    updateStats();
});
